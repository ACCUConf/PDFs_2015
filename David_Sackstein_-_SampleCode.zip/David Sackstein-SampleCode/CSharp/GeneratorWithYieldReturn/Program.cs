﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneratorWithYieldReturn
{
    static class Program
    {
        private static IEnumerable<int> Fibonacci(int count)
        {
            int result = 0;
            for (int i = 0, prev = 1; i < count; i++)
            {
                int temp = result;
                result = result + prev;
                prev = temp;

                yield return result;
            }
        }

        static void Main(string[] args)
        {
            foreach (int i in Fibonacci(5))
            {
                Console.Write("{0} ", i);
            }
            Console.WriteLine();
        }
    }
}
