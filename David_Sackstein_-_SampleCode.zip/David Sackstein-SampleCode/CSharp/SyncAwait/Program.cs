﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace SyncAwait
{
    internal class Program
    {
        #region Sync

        private void DoWork(int arg, Action<string> callback)
        {
            Task.Factory.StartNew(() =>
            {
                Thread.Sleep(2000);
                callback(arg.ToString());
            });
        }

        private void Run()
        {
            DoWork(5, Console.WriteLine);
        }

        #endregion

        #region Async

        private Task<string> DoWorkAsync(int arg)
        {
            return Task.Factory.StartNew(() =>
            {
                Thread.Sleep(2000);
                return arg.ToString();
            });
        }

        private async void RunAsync()
        {
            var result = await DoWorkAsync(5);
            Console.WriteLine(result);
        }

        #endregion

        private static void Main(string[] args)
        {
            new Program().RunAsync();
            Console.WriteLine("Call returned");
            Console.ReadLine();
        }
    }
}