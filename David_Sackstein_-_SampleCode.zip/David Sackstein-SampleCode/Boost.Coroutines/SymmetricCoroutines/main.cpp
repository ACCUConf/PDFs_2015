#include "stdafx.h"
#include <iostream>

#include <boost/coroutine/symmetric_coroutine.hpp>

using yield_type = boost::coroutines::symmetric_coroutine<int>::yield_type;
using call_type = boost::coroutines::symmetric_coroutine<int>::call_type;

call_type* pConsumer;
call_type* pGenerator;

void FibonacciGenerator(yield_type& yield)
{
	int result = 0;
	int i = 0, prev = 1;
	for (;;)
	{
		int temp = result;
		result = result + prev;
		prev = temp;

		yield(*pConsumer, result);
	}
}

void FibonacciConsumer(yield_type& yield)
{
	for (int i = 0; i < 5; i++)
	{
		std::cout << yield.get() << " ";
		yield(*pGenerator, -1);
	}
}

void main()
{
	call_type generator([](yield_type& yield)
	{
		FibonacciGenerator(yield);
	});

	call_type consumer([](yield_type& yield)
	{
		FibonacciConsumer(yield);
	});

	pConsumer = &consumer;
	pGenerator = &generator;

	generator(-1);

	std::cout << "\n";
}

