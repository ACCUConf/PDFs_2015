#include "stdafx.h"
#include <iostream>

#include <boost/coroutine/asymmetric_coroutine.hpp>

using pull_type = boost::coroutines::asymmetric_coroutine<int>::pull_type;
using push_type = boost::coroutines::asymmetric_coroutine<int>::push_type;

void FibonacciGenerator(push_type& push)
{
	int result = 0;
	int i = 0, prev = 1;
	for (;;)
	{
		int temp = result;
		result = result + prev;
		prev = temp;

		push(result);
	}
}

void main()
{
	pull_type pull([] (push_type& push)
	{
		FibonacciGenerator(push);
	});

	for (int i = 0; i < 5; i++)
	{
		std::cout << pull.get() << " ";
		pull();
	}

	std::cout << "\n";

	int i = 0;

	for (auto result : pull)
	{
		std::cout << result << " ";
		if (i++ == 5)
			break;
	}

	std::cout << "\n";
}

