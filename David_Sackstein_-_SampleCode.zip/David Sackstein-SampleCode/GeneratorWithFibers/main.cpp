#include <iostream>
#include "Fiber.h"

void FibonacciGenerator (Fiber& fiber, int& result)
{
	result = 0;
	int i = 0, prev = 1;
	for (;;)
	{
		int temp = result;
		result = result + prev;
		prev = temp;

		fiber.YieldToParent();
	}
}

void main()
{
	int result;
	Fiber fiber([&result](Fiber& f)
	{
		FibonacciGenerator(f, std::ref(result));
	});

	for (int i = 0; i < 5; i++)
	{
		std::cout << result << " ";
		fiber.YieldToChild();
	}

	std::cout << std::endl;
}

