#pragma once

#include <Windows.h>
#include <functional>

class Fiber;

typedef std::function<void(Fiber&)> Routine;

class Fiber 
{
public :

    Fiber (Routine);
    ~Fiber ();

    void YieldToChild ()  { YieldTo (_childFiber); }
    void YieldToParent () { YieldTo (_parentFiber); }

private :

	static VOID WINAPI StaticRun (LPVOID This);
    void Run ();

	void YieldTo (PVOID);

    PVOID _parentFiber;
    PVOID _childFiber;
	PVOID _currFiber;
	Routine _routine;
};
