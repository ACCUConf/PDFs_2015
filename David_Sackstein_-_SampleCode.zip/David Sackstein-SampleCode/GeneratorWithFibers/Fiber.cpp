#include "Fiber.h"

// See this article: http://blogs.msdn.com/oldnewthing/archive/2004/12/31/344799.aspx

Fiber::Fiber (Routine routine) :
	_childFiber (nullptr),
	_currFiber (nullptr),
	_routine (routine)
{
	_parentFiber = ::ConvertThreadToFiber(this);

	if (_parentFiber)
		_childFiber = ::CreateFiber(0x1000, StaticRun, this);

	if (! _childFiber)
		throw std::exception("Failed to create fiber");

	YieldTo(_childFiber);
}

Fiber::~Fiber ()
{
	if (_childFiber)
	{
		::DeleteFiber(_childFiber);
	}
}

void Fiber::Run ()
{
	_routine(*this);
    YieldToParent(); // otherwise the thread will exit
}

VOID WINAPI Fiber::StaticRun(LPVOID _this)
{
    static_cast<Fiber*>(_this)->Run();
}

void Fiber::YieldTo (PVOID fiber)
{
	_currFiber = fiber;
	::SwitchToFiber (fiber);
}
