#include "stdafx.h"

#include "background_worker.h"
#include "foreground_work.h"
#include "my_yield_context.h"

std::string async_call_me_back_later(
	io_service& io_service,
	my_yield_context yield)
{
	typedef std::function<void(const std::string&)> Handler;
	typedef std::function<void(boost::asio::io_service&, Handler)> Function;

	return async_function<std::string, Function> (io_service, yield, call_me_back_later);
}

static void make_sync_async_calls(
	io_service& io_service, int count, my_yield_context yield)
{
	for (int i = 0; i<count; i++)
	{
		std::string message = async_call_me_back_later(io_service, yield);

		std::cout << message << std::endl;
	}
}

void async_with_my_yield_context()
{
	io_service io_service;
	io_service::work work(io_service);

	post_foreground_work(io_service);

	my_spawn([&io_service] (my_yield_context yield)
	{
		make_sync_async_calls(io_service, 5, yield);
	});
	
	while (!_kbhit())
		io_service.poll();

	std::cout << "done";
}