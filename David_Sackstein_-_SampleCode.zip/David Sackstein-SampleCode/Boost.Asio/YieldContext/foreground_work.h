#pragma once

#include <iostream>
#include <boost/asio.hpp>

using namespace boost::asio;

// post a lot of work to the io_service so that we can observe that it gets done
// while background async functions are being called

inline void post_foreground_work(io_service& io_service)
{
	auto ptr = std::make_shared<deadline_timer>(io_service, boost::posix_time::milliseconds(200));
	ptr->async_wait([ptr, &io_service](const boost::system::error_code& ec)
	{
		std::cout << "!";
		if (!ec)
		{
			post_foreground_work(io_service);
		}
	});
}
