#include "stdafx.h"

#include "background_worker.h"
#include "foreground_work.h"

static void make_async_calls(io_service& io_service, int index, int count)
{
	if (index == count)
		return;

	call_me_back_later(
		io_service, [&, index, count] (const std::string& message)
	{
		std::cout << message << std::endl;
		make_async_calls(io_service, index+1, count);
	});
}

void async()
{
	io_service io_service;
	io_service::work work(io_service);

	post_foreground_work(io_service);

	make_async_calls(io_service, 0, 5);

	while (! _kbhit())
		io_service.poll();
}
