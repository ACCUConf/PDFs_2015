#include "stdafx.h"

#include <boost/asio.hpp>
#include <boost/asio/spawn.hpp>
#include "background_worker.h"
#include "foreground_work.h"

template <typename T, typename CompletionToken>
auto async_call_me_back_later(io_service& io_service, CompletionToken&& token)
{
	using handler_type_t = typename handler_type<CompletionToken, void(T)>::type;

	handler_type_t handler(std::forward<CompletionToken>(token));
	async_result<handler_type_t> result(handler);
	call_me_back_later(io_service, handler);
	return result.get();
}

static void make_sync_async_calls(io_service& io_service, int count, yield_context yield)
{
	for (int i = 0; i<count; i++)
	{
		std::string message = async_call_me_back_later<std::string>(io_service, yield);

		std::cout << message << std::endl;
	}
}

void async_with_asio_yield_context()
{
	io_service io_service;
	io_service::work work(io_service);

	post_foreground_work(io_service);

	boost::asio::spawn(io_service, [&io_service] (yield_context yield)
	{
		make_sync_async_calls(io_service, 5, yield);
	});
	
	while (!_kbhit())
		io_service.poll();

	std::cout << "done";
}