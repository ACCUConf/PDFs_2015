#include "stdafx.h"

void sync();

// demonstrates async code with callbacks
void async();

// demonstrates async code that look like sync code using my implementation of yield_context
void async_with_my_yield_context();

// demonstrates async code that look like sync code using asio's implementation of yield_context
void async_with_asio_yield_context();

void main()
{
	async();
}