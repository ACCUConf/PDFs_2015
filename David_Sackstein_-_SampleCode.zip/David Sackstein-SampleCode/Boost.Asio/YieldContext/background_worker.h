#pragma once

#include <functional>
#include <boost/asio.hpp>
#include <filesystem>

using namespace boost::asio;

// simulates an async call with a callback (that takes time to return)

inline void call_me_back_later(
	io_service& io_service,
	std::function<void(const std::string&)> handler)
{
	auto ptr = std::make_shared<deadline_timer>(
		io_service, 
		boost::posix_time::seconds(1));

	ptr->async_wait([ptr, handler](const boost::system::error_code& ec)
	{
		auto now = std::chrono::system_clock::now();
		auto now_time_t = std::chrono::system_clock::to_time_t(now);
		std::string time_str = ctime(&now_time_t);

		handler(time_str);
	});
}
