#pragma once

#include <boost/coroutine/all.hpp>

using namespace boost::coroutines;

// stores the context - pointers to the push and pull coroutines

struct my_yield_context
{
	void pull()
	{
		(*_pPull)();
	}
	void push() { (*_pPush.lock())();}

	std::weak_ptr<push_coroutine<void>> _pPush;
	pull_coroutine<void>* _pPull;
};

// creates a context and runs a user function in a (push) coroutine

inline void my_spawn(std::function<void(my_yield_context&)> user_function)
{
	my_yield_context yield;

	auto pPush = std::make_shared<push_coroutine<void>>(
		[&](pull_coroutine<void>& source)
	{
		yield._pPull = &source;

		// #2
		// now yield is set up with pull and push routine pointers
		user_function(yield);
	});

	yield._pPush = pPush;

	// #1
	// calls #2

	yield.push();
}

template <typename ReturnType, typename Function>
ReturnType async_function(
	io_service& io_service,
	my_yield_context yield,
	Function function)
{
	ReturnType result_;

	auto localPush = yield._pPush.lock();

	function(io_service, [localPush, &result_](const ReturnType& result)
	{
		result_ = std::move(result);
		(*localPush)();
	});

	// release the push object before yielding. 
	// Otherwise if io_service is stopped localPush will leak

	localPush.reset();

	yield.pull();

	return result_;
}

