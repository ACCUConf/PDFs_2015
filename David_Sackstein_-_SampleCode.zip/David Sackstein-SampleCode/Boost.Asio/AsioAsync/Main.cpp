#include "stdafx.h"
#include <conio.h>
#include "EchoClient.h"
#include "EchoServer.h"

void main()
{
	int serverPort = 64002;
	io_service io_service;

	std::shared_ptr<EchoServer> pServer = EchoServer::make_shared(io_service, serverPort);
	pServer->run();

	std::shared_ptr<EchoClient> pClient1 = EchoClient::make_shared(io_service, serverPort, 1);
	pClient1->run();

	std::shared_ptr<EchoClient> pClient2 = EchoClient::make_shared(io_service, serverPort, 2);
	pClient2->run();

	std::thread thread1([&io_service] { io_service.run(); });
	//std::thread thread2([&io_service] { io_service.run(); });
	//std::thread thread3([&io_service] { io_service.run(); });

	std::getchar();

	io_service.stop();

	thread1.join();
	//thread2.join();
	//thread3.join();
}