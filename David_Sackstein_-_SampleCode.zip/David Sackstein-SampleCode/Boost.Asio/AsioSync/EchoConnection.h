#pragma once

#include <boost/enable_shared_from_this.hpp>
#include <thread>
#include "Messenger.h"
#include "Echoer.h"

class EchoConnection
{
public:

	EchoConnection(tcp::socket&&);

	void stop();

private:

	void run();

	tcp::socket _socket;
	Messenger _messenger;
	Echoer _echoer;
	std::thread _thread;
};

typedef std::shared_ptr<EchoConnection> EchoConnectionPtr;

