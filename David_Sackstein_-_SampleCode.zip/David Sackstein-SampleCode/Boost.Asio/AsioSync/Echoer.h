#pragma once

#include <thread>
#include <atomic>
#include "Messenger.h"
#include "Logger.h"

class Echoer
{
public:

	Echoer(Messenger&);

	template<typename T> void write_and_read(T&& message); // perfect forwarding
	void read_and_write();
	void cancel();

private:

	void loop();
	void compare(const Message&);

	std::string ThreadIdString();
	std::string IdToString(std::thread::id&);

	template<typename T> void write(T&& message);  // perfect forwarding

	std::atomic<bool> _is_running;
	Messenger& _messenger;
	Message _sentMessage;
	Logger& _logger = Logger::instance();
};

template<typename T>
inline void Echoer::write_and_read(T&& message)
{
	write(std::forward<T>(message));
	loop();
}

template<typename T>
inline void Echoer::write(T&& message)
{
	_sentMessage = std::forward<T>(message);
	_messenger.write(_sentMessage);
}
